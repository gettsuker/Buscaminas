package model;

import java.io.Serializable;

public class Ganador implements Serializable {
    
    private int Puntuacion;
    
    private String Usuario;

    public Ganador(int Puntuacion, String Usuario) {
        this.Puntuacion = Puntuacion;
        this.Usuario = Usuario;
    }
    
    public int getPuntuacion() {
        return Puntuacion;
    }

    public void setPuntuacion(int Puntuacion) {
        this.Puntuacion = Puntuacion;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String Usuario) {
        this.Usuario = Usuario;
    }
    
    public String toString(){
        
        return "Usuario - "+this.Usuario+" || Puntuación - "+this.Puntuacion;
        
    }
    
}
