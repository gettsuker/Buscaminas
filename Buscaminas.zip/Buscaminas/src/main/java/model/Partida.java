package model;

public class Partida {
    
    private String dificultad;
    
    private Casilla[][] casillero;
    
    private Tamaño tamaño;
    
    private boolean perdida = false;
    
    private int contadorBanderas = 0;
    
    private int casillasPorDescubrir = 0;
    
    public Partida(String dificultad, Casilla[][] casillero) {
        this.dificultad = dificultad;
        this.casillero = casillero;
    }
    
    public Partida(String dificultad, Tamaño tamaño) {
        this.dificultad = dificultad;
        this.tamaño = tamaño;
        this.casillero = crearCasillero(dificultad, tamaño);
        this.casillero = rellenarCampo(this.casillero, tamaño.getFilas(), tamaño.getColumnas());
        this.casillero = numerosAlrededor(tamaño.getFilas(), tamaño.getColumnas());
        
    }
    
    public Casilla[][] crearCasillero(String dificultad, Tamaño tamaño) {
        Casilla[][] casilleroVacio = new Casilla[tamaño.getFilas()][tamaño.getColumnas()];
        return casilleroVacio;
        
    }
    
    public Casilla[][] numerosAlrededor(int x, int y) {
        
        for (int k = 0; k < x; k++) {
            for (int l = 0; l < y; l++) {
                
                int columna = 0;
                int fila = 0;
                if (casillero[k][l].getPosX() == 0) {
                    fila = 1;
                } else if (casillero[k][l].getPosX() == (x - 1)) {
                    fila = 2;
                }
                if (casillero[k][l].getPosY() == 0) {
                    columna = 1;
                } else if (casillero[k][l].getPosY() == (y - 1)) {
                    columna = 2;
                }
                
                int i = -1;
                int j = -1;
                int a = 2;
                int b = 2;
                if (columna == 1) {
                    j = 0;
                }
                if (columna == 2) {
                    b = 1;
                }
                if (fila == 1) {
                    i = 0;
                }
                if (fila == 2) {
                    a = 1;
                }
                
                if (casillero[k][l].getTipo() == true) {
                    
                    for (int w = i; w < a; w++) {
                        for (int z = j; z < b; z++) {
                            
                            if ((w == 0 && z == 0) || casillero[k + w][l + z].getTipo() == true) {
                                
                            } else {
                                casillero[k + w][l + z].setBombasAlrededor();
                            }
                        }
                    }
                }
            }
        }
        return casillero;
    }
    
    public Casilla[][] rellenarCampo(Casilla[][] casilleroRelleno, int a, int b) {
        int nMinas = 0;
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < b; j++) {
                casilleroRelleno[i][j] = new Casilla(i, j);
                
            }
        }
        
        switch (this.dificultad) {
            case "facil":
                nMinas = (a * b) / 9;
                
                contadorBanderas = nMinas;
                
                break;
            case "intermedia":
                nMinas = (int) ((a * b) * (0.15));
                
                contadorBanderas = nMinas;
                
                break;
            case "dificil":
                nMinas = (a * b) / 5;
                
                contadorBanderas = nMinas;
                
                break;
        }
        
        this.casillasPorDescubrir = (a * b) - contadorBanderas;
        
        int randomF = 0;
        int randomC = 0;
        for (int i = 0; i < nMinas;) {
            randomF = (int) (Math.random() * a);
            randomC = (int) (Math.random() * b);
            if (casilleroRelleno[randomF][randomC].getTipo() != true) {
                casilleroRelleno[randomF][randomC].setTipo(true);
                i++;
            }
        }
        return casilleroRelleno;
    }
    
    public void descubrirCasilla(int x, int y) {
        
        if (casillero[x][y].getMarca() == 0 || casillero[x][y].getMarca() == 2) {
            
            if (casillero[x][y].getTipo() == true) {
                
                this.descubrirTablero();
                
            } else {
                if (casillero[x][y].getDescubierto() == false) {
                    this.casillasPorDescubrir--;
                    
                }
                casillero[x][y].setDescubierto(true);
                casillero[x][y].setMarca(0);
                if (casillero[x][y].getBombasAlrededor() != 0) {
                    mostrarColor(x, y);
                } else {
                    
                    int columna = 0;
                    int fila = 0;
                    if (casillero[x][y].getPosX() == 0) {
                        fila = 1;
                    } else if (casillero[x][y].getPosX() == (tamaño.getFilas() - 1)) {
                        fila = 2;
                    }
                    if (casillero[x][y].getPosY() == 0) {
                        columna = 1;
                    } else if (casillero[x][y].getPosY() == (tamaño.getColumnas() - 1)) {
                        columna = 2;
                    }
                    
                    int i = -1;
                    int j = -1;
                    int a = 2;
                    int b = 2;
                    if (columna == 1) {
                        j = 0;
                    }
                    if (columna == 2) {
                        b = 1;
                    }
                    if (fila == 1) {
                        i = 0;
                    }
                    if (fila == 2) {
                        a = 1;
                    }
                    
                    for (int w = i; w < a; w++) {
                        for (int z = j; z < b; z++) {
                            
                            if (casillero[(x + w)][(y + z)].getTipo() == false) {
                                
                                mostrarColor((x + w), (y + z));
                                if (casillero[(x + w)][(y + z)].getDescubierto() == false && casillero[(x + w)][(y + z)].getTipo() == false) {
                                    
                                    descubrirCasilla((x + w), (y + z));
                                    
                                }
                                
                            }
                            
                        }
                        
                    }
                    
                }
                
            }
            
        }
        
    }
    
    public void ponerMarca(int x, int y) {
        
        if (casillero[x][y].getDescubierto() == false && contadorBanderas > 0) {
            casillero[x][y].aumentarMarcar();
            
            if (casillero[x][y].getMarca() == 1) {
                
                contadorBanderas--;
                
            } else if (casillero[x][y].getMarca() == 2) {
                
                contadorBanderas++;
                
            }
            
            mostrarColor(x, y);
        } else if (casillero[x][y].getDescubierto() == false && contadorBanderas == 0 && (casillero[x][y].getMarca() == 1 || casillero[x][y].getMarca() == 2)) {
            casillero[x][y].aumentarMarcar();
            if (casillero[x][y].getMarca() == 1) {
                
                contadorBanderas--;
                
            } else if (casillero[x][y].getMarca() == 2) {
                
                contadorBanderas++;
                
            }
            
            mostrarColor(x, y);
            
        }
        
    }
    
    public void descubrirTablero() {
        for (int i = 0; i < tamaño.getFilas(); i++) {
            for (int j = 0; j < tamaño.getColumnas(); j++) {
                casillero[i][j].setDescubierto(true);
                casillero[i][j].setText(casillero[i][j].toString());
                String color = "-fx-text-fill: black";
                switch (casillero[i][j].getBombasAlrededor()) {
                    
                    case 0:
                        
                        if (casillero[i][j].getTipo() != true) {
                            color = "-fx-background-color: lightgrey; -fx-border-color:white;";
                        }
                        
                        break;
                    
                    case 1:
                        
                        color = "-fx-text-fill: blue;";
                        
                        break;
                    
                    case 2:
                        
                        color = "-fx-text-fill: green";
                        
                        break;
                    
                    case 3:
                        
                        color = "-fx-text-fill: red";
                        break;
                    
                    case 4:
                        
                        color = "-fx-text-fill: purple";
                        
                        break;
                    
                    case 5:
                        
                        color = "-fx-text-fill: brown";
                        
                        break;
                    
                    case 6:
                        
                        color = "-fx-text-fill: turquoise";
                        
                        break;
                    
                    case 7:
                        
                        color = "-fx-text-fill: black";
                        
                        break;
                    
                    case 8:
                        
                        color = "-fx-text-fill: grey";
                        
                        break;
                    
                }
                
                switch (tamaño.getFilas()) {
                    
                    case 7:
                        
                        casillero[i][j].setStyle("-fx-font-size: 40;" + color);
                        
                        break;
                    
                    case 12:
                        
                        casillero[i][j].setStyle("-fx-font-size: 25;" + color);
                        
                        break;
                    
                    case 14:
                        
                        casillero[i][j].setStyle("-fx-font-size: 20;" + color);
                        
                        break;
                    
                    case 20:
                        
                        casillero[i][j].setStyle("-fx-font-size: 15;" + color);
                        
                        break;
                    
                }
                
                casillero[i][j].setDisable(true);
                
                perdida = true;
                
            }
        }
        
    }
    
    public void mostrarColor(int x, int y) {
        String color = "-fx-text-fill: black";
        casillero[x][y].setText(casillero[x][y].toString());
        if (casillero[x][y].getMarca() == 1 || casillero[x][y].getMarca() == 2) {
            switch (tamaño.getFilas()) {
                
                case 7:
                    
                    casillero[x][y].setStyle("-fx-font-size: 40;" + color);
                    
                    break;
                
                case 12:
                    
                    casillero[x][y].setStyle("-fx-font-size: 25;" + color);
                    
                    break;
                
                case 14:
                    
                    casillero[x][y].setStyle("-fx-font-size: 20;" + color);
                    
                    break;
                
                case 20:
                    
                    casillero[x][y].setStyle("-fx-font-size: 15;" + color);
                    
                    break;
                
            }
            
        } else if (casillero[x][y].getMarca() == 0 && casillero[x][y].getDescubierto() == true) {
            
            switch (casillero[x][y].getBombasAlrededor()) {
                
                case 0:
                    if (casillero[x][y].getTipo() != true) {
                        color = "-fx-background-color: lightgrey;";
                    }
                    break;
                case 1:
                    
                    color = "-fx-text-fill: blue;";
                    
                    break;
                
                case 2:
                    
                    color = "-fx-text-fill: green";
                    
                    break;
                
                case 3:
                    
                    color = "-fx-text-fill: red";
                    break;
                
                case 4:
                    
                    color = "-fx-text-fill: purple";
                    
                    break;
                
                case 5:
                    
                    color = "-fx-text-fill: brown";
                    
                    break;
                
                case 6:
                    
                    color = "-fx-text-fill: turquoise";
                    
                    break;
                
                case 7:
                    
                    color = "-fx-text-fill: black";
                    
                    break;
                
                case 8:
                    
                    color = "-fx-text-fill: grey";
                    
                    break;
                
            }
            
            switch (tamaño.getFilas()) {
                
                case 7:
                    
                    casillero[x][y].setStyle("-fx-font-size: 40;" + color);
                    
                    break;
                
                case 12:
                    
                    casillero[x][y].setStyle("-fx-font-size: 25;" + color);
                    
                    break;
                
                case 14:
                    
                    casillero[x][y].setStyle("-fx-font-size: 20;" + color);
                    
                    break;
                
                case 20:
                    
                    casillero[x][y].setStyle("-fx-font-size: 15;" + color);
                    
                    break;
                
            }
        }
        
    }
    
    public String getDificultad() {
        return dificultad;
    }
    
    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }
    
    public Casilla[][] getCasillero() {
        return casillero;
    }
    
    public void setCasillero(Casilla[][] casillero) {
        this.casillero = casillero;
    }
    
    public Casilla getCasilla(int a, int b) {
        return this.casillero[a][b];
    }
    
    public Tamaño getTamaño() {
        return tamaño;
    }
    
    public void setTamaño(Tamaño tamaño) {
        this.tamaño = tamaño;
    }
    
    public int getContadorBanderas() {
        return contadorBanderas;
    }
    
    public void setContadorBanderas(int contadorBanderas) {
        this.contadorBanderas = contadorBanderas;
    }
    
    public boolean isPerdida() {
        return perdida;
    }
    
    public void setPerdida(boolean perdida) {
        this.perdida = perdida;
    }
    
    public int getCasillasPorDescubrir() {
        return casillasPorDescubrir;
    }
    
    public void setCasillasPorDescubrir(int casillasPorDescubrir) {
        this.casillasPorDescubrir = casillasPorDescubrir;
    }
    
}
