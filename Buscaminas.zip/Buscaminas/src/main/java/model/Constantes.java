package model;

public class Constantes {

    public static final String FondoRetro =  "/Images/FondoRetro.jpg";

    public static final String FondoPartidaRetro = "/Images/FondoPartidaRetro.jpg";

    public static final String FondoBosque = "/Images/FondoBosque.jpg";

    public static final String FondoPartidaBosque = "/Images/FondoPartidaBosque.jpg";

    public static final String FondoDesierto = "/Images/FondoDesierto.jpg";

    public static final String FondoPartidaDesierto = "/Images/FondoPartidaDesierto.jpg";
    
    public static final String Icono = "/Images/Icono_Bomba.jpg";

    public static final String estiloTextoTituloRetro = "-fx-fill: #087dd0; -fx-font-family: Audiowide Regular; -fx-font-family-size: 75;";

    public static final String estiloTextosRetro = "-fx-fill: #087dd0; -fx-font-family: Audiowide Regular; -fx-font-family-size: 40;";

    public static final String estiloTextoTituloDesierto = "-fx-fill: #865900; -fx-font-family: Audiowide Regular; -fx-font-family-size: 75;";

    public static final String estiloTextosDesierto = "-fx-fill: #895200; -fx-font-family: Audiowide Regular; -fx-font-family-size: 40;";

    public static final String estiloTextoTituloBosque = "-fx-fill: #007802; -fx-font-family: Audiowide Regular; -fx-font-family-size: 75;";

    public static final String estiloTextosBosque = "-fx-fill: #5ff86c; -fx-font-family: Audiowide Regular; -fx-font-family-size: 40;";

    public static final String estiloRelojBosque = "-fx-fill: white; -fx-font-family: Audiowide Regular; -fx-font-family-size: 40;";

    public static final String estiloRelojDesierto = "-fx-fill: #b50012; -fx-font-family: Audiowide Regular; -fx-font-family-size: 40;";

    public static final String estiloRelojRetro = "-fx-fill: #087dd0; -fx-font-family: Audiowide Regular; -fx-font-family-size: 40;";

}
