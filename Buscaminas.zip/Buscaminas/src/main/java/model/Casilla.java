package model;

import javafx.scene.control.Button;
import javafx.scene.shape.Rectangle;

public class Casilla extends Button {

    private int marca = 0;

    private boolean descubierto = false;

    private boolean tipo;

    private int posX;

    private int posY;

    private int bombasAlrededor = 0;

    public Casilla(Casilla casilla, Rectangle rectangle) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Casilla(int a, int b) {

        this.posX = a;

        this.posY = b;

    }

    @Override
    public String toString() {

        String devolver = "@";

        if (descubierto == true) {

            if (tipo == true) {

                devolver = "\u2699";

            } else {

                if (this.bombasAlrededor == 0) {

                    devolver = "";

                } else {

                    devolver = ""+bombasAlrededor;

                }

            }

        } else {

            switch (marca) {

                case 0:

                    devolver = "";

                    break;

                case 1:

                    devolver = "\u2691";

                    break;

                case 2:

                    devolver = "?";

                    break;

            }

        }
//        if (this.tipo == true) {
//
//            devolver = "\u2699";
//
//        }
//        
//        else {
//
//            if (this.bombasAlrededor == 0) {
//
//                devolver = "";
//
//            }
//            
//            else {
//                
//                devolver = "" + bombasAlrededor;
//                
//                
//                
//            }
//
//        }

        return devolver;

    }

    public int getMarca() {
        return marca;
    }

    public void aumentarMarcar() {
        this.marca++;

        if (this.marca > 2) {

            this.marca = 0;

        }
    }

    public void setMarca(int x) {

        this.marca = x;
    }

    public boolean getDescubierto() {
        return descubierto;
    }

    public void setDescubierto(boolean descubierto) {
        this.descubierto = descubierto;
    }

    public boolean getTipo() {
        return tipo;
    }

    public void setTipo(boolean tipo) {
        this.tipo = tipo;
    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }

    public int getBombasAlrededor() {
        return bombasAlrededor;
    }

    public void setBombasAlrededor() {

        this.bombasAlrededor++;

    }

}
