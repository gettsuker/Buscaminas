package main;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.Constantes;

/**
 *
 * @author Gozyy
 */
public class Main extends Application {

    @Override
    public void start(Stage primaryStage)
            throws IOException {
        primaryStage.getIcons().add(new Image(Constantes.Icono));
        FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource("/FXML/Escenario.fxml"));
        BorderPane root = loaderMenu.load();

        Scene scene = new Scene(root);
//        scene.getStylesheets().add("css/fxmlScene.css");
        primaryStage.setTitle("Buscaminas");
        primaryStage.setScene(scene);
        primaryStage.show();
        //para no poder maximizar pantalla y
        primaryStage.setResizable(true);
    }

    public static void main(String[] args) {
        launch(args);
    }

}
