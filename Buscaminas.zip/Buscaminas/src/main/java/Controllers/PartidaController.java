package Controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.util.Duration;
import model.Casilla;
import model.Constantes;
import model.Partida;
import model.Tamaño;

public class PartidaController implements Initializable {

    private String dificultad;
    private Tamaño tamaño;

    private Partida partida;

    private EscenarioController escenario;

    @FXML
    private ImageView fondoPartida;

    @FXML
    private GridPane casillero;

    @FXML
    private Text reloj;

    @FXML
    private Text banderas;

    @FXML
    private Text textoMensaje;

    @FXML
    private Button botonRanking;

    private Constantes cons;

    private int minuto = 0;
    private int hora = 0;
    private int segundo = -1;
    private int minuto2 = 0;
    private int hora2 = 0;
    private int segundo2;
    private Timeline clock;
    private int puntuacion = 0;
    private int tiempo = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            segundo++;
            tiempo = (segundo + (segundo2 * 10) + (minuto * 60) + (minuto2 * 600) + (hora * 3600) + (hora2 * 36000));
            if (segundo == 10) {

                segundo = 0;

                segundo2++;

                if (segundo2 == 6) {

                    minuto++;

                    segundo2 = 0;

                }

                if (minuto == 10) {

                    minuto2++;

                    minuto = 0;

                    if (minuto2 == 6) {

                        hora++;

                        minuto2 = 0;

                        if (hora == 10) {

                            hora2++;

                            hora = 0;

                        }

                    }

                }

            }
            reloj.setText(hora2 + "" + hora + ":" + (minuto2 + "" + minuto) + ":" + segundo2 + "" + segundo);

        }),
                new KeyFrame(Duration.seconds(1))
        );

        clock.setCycleCount(Animation.INDEFINITE);
        clock.play();
    }

    public void clearPartida() {

        casillero.getChildren().clear();

        escenario.cargarPartida(dificultad, tamaño);

    }

    public Partida crearPartida() {

        switch (escenario.getTema()) {
            case "Retro":
                this.cambiarRetro();
                break;
            case "Desierto":
                this.cambiarDesierto();
                break;
            case "Bosque":
                this.cambiarBosque();
                break;
            default:
                this.cambiarRetro();
                break;

        }

        casillero.getChildren().clear();

        partida = new Partida(dificultad, tamaño);

        for (int i = 0; i < tamaño.getFilas(); i++) {
            for (int j = 0; j < tamaño.getColumnas(); j++) {
                partida.getCasilla(i, j).setOnMouseClicked(new EventHandler<MouseEvent>() {

                    @Override
                    public void handle(MouseEvent event) {

                        MouseButton button = event.getButton();

                        if (button == MouseButton.PRIMARY) {

                            partida.descubrirCasilla(((Casilla) event.getSource()).getPosX(), ((Casilla) event.getSource()).getPosY());

                            if (partida.isPerdida()) {

                                clock.stop();

                                textoMensaje.setText("Has perdido ... (¬_¬)");

                            }
                            GG();

                        } else if (button == MouseButton.SECONDARY) {

                            partida.ponerMarca(((Casilla) event.getSource()).getPosX(), ((Casilla) event.getSource()).getPosY());
                            banderas.setText("" + partida.getContadorBanderas());
                            GG();
                        }
                    }

                });
                casillero.add(partida.getCasilla(i, j), j, i);

            }
        }
        banderas.setText("" + partida.getContadorBanderas());
        return partida;
    }

    public String getDificultad() {
        return dificultad;
    }

    public void GG() {

        if (partida.getCasillasPorDescubrir() == 0) {
            partidaGanada();
        }
    }

    public void partidaGanada() {
        int dif = 0;

        int tam = 0;
        partida.setContadorBanderas(0);
        banderas.setText("" + partida.getContadorBanderas());
        partida.descubrirTablero();

        switch (dificultad) {
            case "facil":
                dif = 150;
                break;
            case "intermedia":
                dif = 300;
                break;
            case "dificil":
                dif = 700;
                break;
        }
        switch (tamaño.getFilas()) {
            case 7:
                tam = 150;
                break;
            case 12:
                tam = 300;
                break;
            case 14:
                tam = 400;
                break;
            case 20:
                tam = 800;
                break;

        }

        if (dificultad.equals("dificil") && tamaño.getFilas() == 20) {

            dif = 1500;

            tam = 1000;

        }

        puntuacion = (int) ((dif * tam) / (tiempo * 0.1));
        escenario.pasarPuntuacion(puntuacion);

        textoMensaje.setText("¡ Has ganado ! ");

        botonRanking.setVisible(true);

        clock.stop();

    }

    public void clickMenu() {
        escenario.cargarMenuPrincipal();
    }

    public void clickRanking() {

        escenario.actualizarRanking();

    }

    public Partida getPartida() {
        return partida;
    }

    public void setPartida(Partida partida) {
        this.partida = partida;
    }

    public ImageView getFondoPartida() {
        return fondoPartida;
    }

    public void setFondoPartida(ImageView fondoPartida) {
        this.fondoPartida = fondoPartida;
    }

    public Text getReloj() {
        return reloj;
    }

    public void setReloj(Text reloj) {
        this.reloj = reloj;
    }

    public Text getBanderas() {
        return banderas;
    }

    public void setBanderas(Text banderas) {
        this.banderas = banderas;
    }

    public Text getTextoMensaje() {
        return textoMensaje;
    }

    public void setTextoMensaje(Text textoMensaje) {
        this.textoMensaje = textoMensaje;
    }

    public Button getBotonRanking() {
        return botonRanking;
    }

    public void setBotonRanking(Button botonRanking) {
        this.botonRanking = botonRanking;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }

    public int getSegundo() {
        return segundo;
    }

    public void setSegundo(int segundo) {
        this.segundo = segundo;
    }

    public int getMinuto2() {
        return minuto2;
    }

    public void setMinuto2(int minuto2) {
        this.minuto2 = minuto2;
    }

    public int getHora2() {
        return hora2;
    }

    public void setHora2(int hora2) {
        this.hora2 = hora2;
    }

    public int getSegundo2() {
        return segundo2;
    }

    public void setSegundo2(int segundo2) {
        this.segundo2 = segundo2;
    }

    public Timeline getClock() {
        return clock;
    }

    public void setClock(Timeline clock) {
        this.clock = clock;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public int getTiempo() {
        return tiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }

    public Tamaño getTamaño() {
        return tamaño;
    }

    public void setTamaño(Tamaño tamaño) {
        this.tamaño = tamaño;
    }

    public EscenarioController getEscenario() {
        return escenario;
    }

    public void setEscenario(EscenarioController escenario) {
        this.escenario = escenario;
    }

    public GridPane getCasillero() {
        return casillero;
    }

    public void setCasillero(GridPane casillero) {
        this.casillero = casillero;
    }

    public void cambiarRetro() {
        Image a = new Image(getClass().getResource(cons.FondoPartidaRetro).toString());
        fondoPartida.setImage(a);

        banderas.setStyle(cons.estiloRelojRetro);
        textoMensaje.setStyle(cons.estiloRelojRetro);
        reloj.setStyle(cons.estiloRelojRetro);

    }

    public void cambiarDesierto() {
        Image a = new Image(getClass().getResource(cons.FondoPartidaDesierto).toString());
        fondoPartida.setImage(a);

        banderas.setStyle(cons.estiloRelojDesierto);
        textoMensaje.setStyle(cons.estiloRelojDesierto);

        reloj.setStyle(cons.estiloRelojDesierto);

    }

    public void cambiarBosque() {
        Image a = new Image(getClass().getResource(cons.FondoPartidaBosque).toString());
        fondoPartida.setImage(a);

        banderas.setStyle(cons.estiloRelojBosque);
        textoMensaje.setStyle(cons.estiloRelojBosque);

        reloj.setStyle(cons.estiloRelojBosque);

    }

    @Override
    public String toString() {
        return "PartidaController{" + "dificultad=" + dificultad + ", tama\u00f1o=" + tamaño + ", escenario=" + escenario + ", casillero=" + casillero + '}';
    }

}
