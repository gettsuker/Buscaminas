package Controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import model.Constantes;
import model.Tamaño;

public class MenuDificultadController implements Initializable {

    private EscenarioController escenario;

    @FXML
    private ImageView fondoDificultad;

    @FXML
    private Text tituloDificultad;

    @FXML
    private Text botonFacil;

    @FXML
    private Text botonIntermedia;
    
    @FXML
    private Text botonDificil;

    @FXML
    private RadioButton facil;

    @FXML
    private RadioButton intermedia;

    @FXML
    private RadioButton dificil;

    @FXML
    private ComboBox comboTamaño;

    @FXML
    private Label errorTamaño;

    private ArrayList<Tamaño> tamaños;

    private Constantes cons;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tamaños = new ArrayList<>();
        tamaños.add(new Tamaño(7, 10));
        tamaños.add(new Tamaño(12, 16));
        tamaños.add(new Tamaño(14, 20));
        tamaños.add(new Tamaño(20, 26));
        comboTamaño.getItems().addAll(tamaños);
        errorTamaño.setVisible(false);

    }

    public void clickMenu() {
        escenario.cargarMenuPrincipal();
        errorTamaño.setVisible(false);
    }

    public void clickJugar() {
        String dificultad = "";

        if (facil.selectedProperty().getValue()) {
            dificultad = "facil";
        } else if (intermedia.selectedProperty().getValue()) {
            dificultad = "intermedia";
        } else if (dificil.selectedProperty().getValue()) {
            dificultad = "dificil";
        }

        if (null != comboTamaño.getSelectionModel().getSelectedItem()) {

            escenario.cargarPartida(dificultad, (Tamaño) comboTamaño.getSelectionModel().getSelectedItem());

        } else {

            errorTamaño.setVisible(true);

        }

    }
    public void limpiarError(){
    errorTamaño.setVisible(false);
    }

    public EscenarioController getEscenario() {
        return escenario;
    }

    public void setEscenario(EscenarioController escenario) {
        errorTamaño.setVisible(false);
        this.escenario = escenario;

    }

    public ImageView getFondoDificultad() {
        return fondoDificultad;
    }

    public void setFondoDificultad(ImageView fondoDificultad) {
        this.fondoDificultad = fondoDificultad;
    }

    public Text getTituloDificultad() {
        return tituloDificultad;
    }

    public void setTituloDificultad(Text tituloDificultad) {
        this.tituloDificultad = tituloDificultad;
    }

    public Text getBotonFacil() {
        return botonFacil;
    }

    public void setBotonFacil(Text botonFacil) {
        this.botonFacil = botonFacil;
    }

    public Text getBotonIntermedia() {
        return botonIntermedia;
    }

    public void setBotonIntermedia(Text botonIntermedia) {
        this.botonIntermedia = botonIntermedia;
    }

    public Text getBotonDificil() {
        return botonDificil;
    }

    public void setBotonDificil(Text botonDificil) {
        this.botonDificil = botonDificil;
    }

    public RadioButton getFacil() {
        return facil;
    }

    public void setFacil(RadioButton facil) {
        this.facil = facil;
    }

    public RadioButton getIntermedia() {
        return intermedia;
    }

    public void setIntermedia(RadioButton intermedia) {
        this.intermedia = intermedia;
    }

    public RadioButton getDificil() {
        return dificil;
    }

    public void setDificil(RadioButton dificil) {
        this.dificil = dificil;
    }

    public ComboBox getComboTamaño() {
        return comboTamaño;
    }

    public void setComboTamaño(ComboBox comboTamaño) {
        this.comboTamaño = comboTamaño;
    }

    public Label getErrorTamaño() {
        return errorTamaño;
    }

    public void setErrorTamaño(Label errorTamaño) {
        this.errorTamaño = errorTamaño;
    }

    public ArrayList<Tamaño> getTamaños() {
        return tamaños;
    }

    public void setTamaños(ArrayList<Tamaño> tamaños) {
        this.tamaños = tamaños;
    }

    public void cambiarRetro() {
        Image a = new Image(getClass().getResource(cons.FondoRetro).toString());
        fondoDificultad.setImage(a);

        tituloDificultad.setStyle(cons.estiloTextoTituloRetro);
        botonFacil.setStyle(cons.estiloTextosRetro);
        botonIntermedia.setStyle(cons.estiloTextosRetro);
        botonDificil.setStyle(cons.estiloTextosRetro);

    }

    public void cambiarDesierto() {
        Image a = new Image(getClass().getResource(cons.FondoDesierto).toString());
        fondoDificultad.setImage(a);

        tituloDificultad.setStyle(cons.estiloTextoTituloDesierto);
        botonFacil.setStyle(cons.estiloTextosDesierto);
        botonIntermedia.setStyle(cons.estiloTextosDesierto);
        botonDificil.setStyle(cons.estiloTextosDesierto);

    }

    public void cambiarBosque() {
        Image a = new Image(getClass().getResource(cons.FondoBosque).toString());
        fondoDificultad.setImage(a);

        tituloDificultad.setStyle(cons.estiloTextoTituloBosque);
        botonFacil.setStyle(cons.estiloTextosBosque);
        botonIntermedia.setStyle(cons.estiloTextosBosque);
        botonDificil.setStyle(cons.estiloTextosBosque);

    }

}
