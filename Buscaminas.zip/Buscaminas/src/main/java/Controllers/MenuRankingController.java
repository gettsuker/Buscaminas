package Controllers;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import model.Constantes;
import model.Ganador;

public class MenuRankingController implements Initializable {

    @FXML
    private TextField usuarioRanking;

    @FXML
    private ListView Ranking;

    @FXML
    private Button añadirPuntuacion;

    @FXML
    private ImageView fondoRanking;

    @FXML
    private Text tituloRanking;

    @FXML
    private Text textoRanking;

    private Constantes cons;

    private ArrayList<Ganador> Ganadores = new ArrayList<>();

    public String nombreFicheroBinario = "FicheroBinarioGanadores";

    private EscenarioController escenario;
    private int puntuacion = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Ranking.getItems().clear();

        try {
            leerFicheroBinario();
        } catch (IOException ex) {
            Logger.getLogger(MenuRankingController.class.getName()).log(Level.SEVERE, null, ex);

            try {
                escribirFicheroBinario();

            } catch (IOException ex1) {
                Logger.getLogger(MenuRankingController.class.getName()).log(Level.SEVERE, null, ex1);
            }

            Ranking.getItems().addAll(Ganadores);

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MenuRankingController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void setEscenario(EscenarioController escenario) {
        this.escenario = escenario;
    }

    public void clickMenu() {
        añadirPuntuacion.setVisible(false);

        usuarioRanking.setVisible(false);

        textoRanking.setVisible(false);
        escenario.cargarMenuPrincipal();
    }

    public void añadirPuntuacion() throws IOException, FileNotFoundException, ClassNotFoundException {

        String Usuario = usuarioRanking.getText();

        Ganador ganador = new Ganador(puntuacion, Usuario);

        Ganadores.add(ganador);

        for (int j = 0; j < Ganadores.size() - 1; j++) {

            for (int i = 0; i < Ganadores.size(); i++) {

                if (i < Ganadores.size() - 1) {

                    if (Ganadores.get(i + 1).getPuntuacion() > Ganadores.get(i).getPuntuacion()) {

                        Ganador aux = Ganadores.get(i);

                        Ganadores.set(i, Ganadores.get(i + 1));

                        Ganadores.set(i + 1, aux);

                    }

                }

            }
        }

        escribirFicheroBinario();

        Ranking.getItems().clear();

        leerFicheroBinario();

        Ranking.getItems().addAll(Ganadores);

        añadirPuntuacion.setVisible(false);

        usuarioRanking.setVisible(false);

        textoRanking.setVisible(false);

    }

    public void mostraMenus() {
        añadirPuntuacion.setVisible(true);

        usuarioRanking.setVisible(true);

        textoRanking.setVisible(true);
    }

    public TextField getUsuarioRanking() {
        return usuarioRanking;
    }

    public void setUsuarioRanking(TextField usuarioRanking) {
        this.usuarioRanking = usuarioRanking;
    }

    public ListView getRanking() {
        return Ranking;
    }

    public void setRanking(ListView Ranking) {
        this.Ranking = Ranking;
    }

    public Button getAñadirPuntuacion() {
        return añadirPuntuacion;
    }

    public void setAñadirPuntuacion(Button añadirPuntuacion) {
        this.añadirPuntuacion = añadirPuntuacion;
    }

    public ImageView getFondoRanking() {
        return fondoRanking;
    }

    public void setFondoRanking(ImageView fondoRanking) {
        this.fondoRanking = fondoRanking;
    }

    public Text getTituloRanking() {
        return tituloRanking;
    }

    public void setTituloRanking(Text tituloRanking) {
        this.tituloRanking = tituloRanking;
    }

    public Text getTextoRanking() {
        return textoRanking;
    }

    public void setTextoRanking(Text textoRanking) {
        this.textoRanking = textoRanking;
    }

    public ArrayList<Ganador> getGanadores() {
        return Ganadores;
    }

    public void setGanadores(ArrayList<Ganador> Ganadores) {
        this.Ganadores = Ganadores;
    }

    public String getNombreFicheroBinario() {
        return nombreFicheroBinario;
    }

    public void setNombreFicheroBinario(String nombreFicheroBinario) {
        this.nombreFicheroBinario = nombreFicheroBinario;
    }

    public int getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public void escribirFicheroBinario() throws FileNotFoundException, IOException {

        FileOutputStream fs = new FileOutputStream(nombreFicheroBinario);
        try (ObjectOutputStream os = new ObjectOutputStream(fs)) {
            os.writeObject(Ganadores);

        }

    }

    public void leerFicheroBinario() throws FileNotFoundException, IOException, ClassNotFoundException {

        FileInputStream fis = new FileInputStream(nombreFicheroBinario);
        try (ObjectInputStream ois = new ObjectInputStream(fis)) {
            this.Ganadores = (ArrayList<Ganador>) ois.readObject();

        }

    }

    public void cambiarRetro() {
        Image a = new Image(getClass().getResource(cons.FondoRetro).toString());
        fondoRanking.setImage(a);

        tituloRanking.setStyle(cons.estiloTextoTituloRetro);
        textoRanking.setStyle(cons.estiloTextosRetro);

    }

    public void cambiarDesierto() {
        Image a = new Image(getClass().getResource(cons.FondoDesierto).toString());
        fondoRanking.setImage(a);

        tituloRanking.setStyle(cons.estiloTextoTituloDesierto);
        textoRanking.setStyle(cons.estiloTextosDesierto);

    }

    public void cambiarBosque() {
        Image a = new Image(getClass().getResource(cons.FondoBosque).toString());
        fondoRanking.setImage(a);

        tituloRanking.setStyle(cons.estiloTextoTituloBosque);
        textoRanking.setStyle(cons.estiloTextosBosque);

    }

}
