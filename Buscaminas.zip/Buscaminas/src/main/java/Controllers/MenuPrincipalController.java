package Controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import model.Constantes;

public class MenuPrincipalController implements Initializable {

    @FXML
    private ImageView fondoPrincipal;

    @FXML
    private Text tituloPrincipal;

    private EscenarioController escenario;
    private Constantes cons;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void clickOpciones() {
        escenario.cargarMenuOpciones();
    }

    public void clickNuevaPartida() {
        
        escenario.cargarMenuDificultad();
        
    }

    public void clickRanking() {

        escenario.cargarMenuRanking();
    }

    public ImageView getFondoPrincipal() {
        return fondoPrincipal;
    }

    public void setFondoPrincipal(ImageView fondoPrincipal) {
        this.fondoPrincipal = fondoPrincipal;
    }

    public Text getTituloPrincipal() {
        return tituloPrincipal;
    }

    public void setTituloPrincipal(Text tituloPrincipal) {
        this.tituloPrincipal = tituloPrincipal;
    }

    public EscenarioController getEscenario() {
        return escenario;
    }

    public void setEscenario(EscenarioController escenario) {
        this.escenario = escenario;
    }

    public void cambiarRetro() {
        Image a = new Image(getClass().getResource(cons.FondoRetro).toString());
        fondoPrincipal.setImage(a);
        
        tituloPrincipal.setStyle(cons.estiloTextoTituloRetro);

    }

    public void cambiarDesierto() {
        Image a = new Image(getClass().getResource(cons.FondoDesierto).toString());
        fondoPrincipal.setImage(a);
        
        tituloPrincipal.setStyle(cons.estiloTextoTituloDesierto);

    }

    public void cambiarBosque() {
        Image a = new Image(getClass().getResource(cons.FondoBosque).toString());
        fondoPrincipal.setImage(a);
        
        tituloPrincipal.setStyle(cons.estiloTextoTituloBosque);

    }

}
