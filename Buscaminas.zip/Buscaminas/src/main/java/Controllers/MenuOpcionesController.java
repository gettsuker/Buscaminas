package Controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import model.Constantes;

public class MenuOpcionesController implements Initializable {

    private EscenarioController escenario;

    @FXML
    private ImageView fondoOpciones;

    @FXML
    private Text tituloOpciones;

    @FXML
    private Text textoIdioma;

    @FXML
    private Text textoTema;

    private Constantes cons;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void clickMenu() {
        escenario.cargarMenuPrincipal();
    }

    public EscenarioController getEscenario() {
        return escenario;
    }

    public void setEscenario(EscenarioController escenario) {
        this.escenario = escenario;
    }

    public void cambiarRetro() {

        escenario.cambiarRetro();
        escenario.setTema("Retro");
        Image a = new Image(getClass().getResource(cons.FondoRetro).toString());
        fondoOpciones.setImage(a);
        tituloOpciones.setStyle(cons.estiloTextoTituloRetro);
        textoTema.setStyle(cons.estiloTextosRetro);

    }

    public void cambiarDesierto() {

        escenario.cambiarDesierto();
        escenario.setTema("Desierto");
        Image a = new Image(getClass().getResource(cons.FondoDesierto).toString());
        fondoOpciones.setImage(a);

        tituloOpciones.setStyle(cons.estiloTextoTituloDesierto);
        textoTema.setStyle(cons.estiloTextosDesierto);

    }

    public void cambiarBosque() {

        escenario.cambiarBosque();
        escenario.setTema("Bosque");
        Image a = new Image(getClass().getResource(cons.FondoBosque).toString());
        fondoOpciones.setImage(a);

        tituloOpciones.setStyle(cons.estiloTextoTituloBosque);
        textoTema.setStyle(cons.estiloTextosBosque);

    }

    public ImageView getFondoOpciones() {
        return fondoOpciones;
    }

    public void setFondoOpciones(ImageView fondoOpciones) {
        this.fondoOpciones = fondoOpciones;
    }

    public Text getTituloOpciones() {
        return tituloOpciones;
    }

    public void setTituloOpciones(Text tituloOpciones) {
        this.tituloOpciones = tituloOpciones;
    }

    public Text getTextoIdioma() {
        return textoIdioma;
    }

    public void setTextoIdioma(Text textoIdioma) {
        this.textoIdioma = textoIdioma;
    }

    public Text getTextoTema() {
        return textoTema;
    }

    public void setTextoTema(Text textoTema) {
        this.textoTema = textoTema;
    }

}
