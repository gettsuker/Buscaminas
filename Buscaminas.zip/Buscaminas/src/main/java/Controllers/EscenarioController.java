package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import model.Partida;
import model.Tamaño;

public class EscenarioController implements Initializable {
    
    @FXML
    private BorderPane fxRoot;
    
    @FXML
    private AnchorPane pantallaMenuPrincipal;
    private MenuPrincipalController controllerMenuPrincipal;
    
    @FXML
    private AnchorPane pantallaMenuOpciones;
    private MenuOpcionesController controllerMenuOpciones;
    
    @FXML
    private AnchorPane pantallaMenuDificultad;
    private MenuDificultadController controllerMenuDificultad;
    
    @FXML
    private AnchorPane pantallaPartida;
    private PartidaController controllerPartida;
    
    @FXML
    private AnchorPane pantallaRanking;
    private MenuRankingController controllerRanking;
    
    private int puntuacion = 0;
    private String tema = "";
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        preCargarMenuPrincipal();
        preCargarMenuOpciones();
        preCargarMenuDificultad();
        preCargarRanking();
        controllerMenuOpciones.cambiarRetro();
        cargarMenuPrincipal();
    }
    
    public void pasarPuntuacion(int a) {
        controllerRanking.setPuntuacion(a);
    }
    
    private void preCargarMenuOpciones() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource("/FXML/MenuOpciones.fxml"));
            pantallaMenuOpciones = loaderMenu.load();
            controllerMenuOpciones = loaderMenu.getController();
            
            controllerMenuOpciones.setEscenario(this);  //IMPORTANTE

        } catch (IOException ex) {
            Logger.getLogger(EscenarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void preCargarMenuDificultad() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource("/FXML/MenuDificultad.fxml"));
            pantallaMenuDificultad = loaderMenu.load();
            controllerMenuDificultad = loaderMenu.getController();
            
            controllerMenuDificultad.setEscenario(this);  //IMPORTANTE

        } catch (IOException ex) {
            Logger.getLogger(EscenarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void preCargarMenuPrincipal() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource("/FXML/MenuPrincipal.fxml"));
            pantallaMenuPrincipal = loaderMenu.load();
            controllerMenuPrincipal = loaderMenu.getController();
            
            controllerMenuPrincipal.setEscenario(this);  //IMPORTANTE

        } catch (IOException ex) {
            Logger.getLogger(EscenarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void preCargarPartida() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource("/FXML/Partida.fxml"));
            pantallaPartida = loaderMenu.load();
            controllerPartida = loaderMenu.getController();
            
            controllerPartida.setEscenario(this);  //IMPORTANTE

        } catch (IOException ex) {
            Logger.getLogger(EscenarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void preCargarRanking() {
        try {
            FXMLLoader loaderMenu = new FXMLLoader(getClass().getResource("/FXML/Ranking.fxml"));
            pantallaRanking = loaderMenu.load();
            controllerRanking = loaderMenu.getController();
            
            controllerRanking.setEscenario(this);  //IMPORTANTE

        } catch (IOException ex) {
            Logger.getLogger(EscenarioController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void cargarMenuPrincipal() {
        fxRoot.setCenter(pantallaMenuPrincipal);
    }
    
    public void cargarMenuOpciones() {
        fxRoot.setCenter(pantallaMenuOpciones);
    }
    
    public void cargarMenuDificultad() {
        controllerMenuDificultad.getErrorTamaño().setVisible(false);
        fxRoot.setCenter(pantallaMenuDificultad);
    }
    
    public void cargarPartida(String dificultad, Tamaño tamaño) {
        preCargarPartida();
        
        controllerPartida.setTamaño(tamaño);
        controllerPartida.setDificultad(dificultad);
        Partida partida = controllerPartida.crearPartida();
        
        for (int i = 0; i < tamaño.getFilas(); i++) {
            
            for (int j = 0; j < tamaño.getColumnas(); j++) {
                
                partida.getCasilla(i, j).setMinHeight((int) 700 / tamaño.getFilas());
                
                partida.getCasilla(i, j).setMinWidth(900 / tamaño.getColumnas());
                
            }
        }
        
        fxRoot.setCenter(pantallaPartida);
        
    }
    
    public void cargarMenuRanking() {
        fxRoot.setCenter(pantallaRanking);
    }
    
    public void actualizarRanking() {
        
        fxRoot.setCenter(pantallaRanking);
        controllerRanking.mostraMenus();
        
    }
    
    public String getTema() {
        return tema;
    }
    
    public void setTema(String tema) {
        this.tema = tema;
    }
    
    public void cambiarRetro() {
        
        controllerMenuPrincipal.cambiarRetro();
        controllerMenuDificultad.cambiarRetro();
        controllerRanking.cambiarRetro();
        
    }
    
    public void cambiarDesierto() {
        
        controllerMenuPrincipal.cambiarDesierto();
        controllerMenuDificultad.cambiarDesierto();
        controllerRanking.cambiarDesierto();
        
    }
    
    public void cambiarBosque() {
        
        controllerMenuPrincipal.cambiarBosque();
        controllerMenuDificultad.cambiarBosque();
        controllerRanking.cambiarBosque();
        
    }
    
}
